import type { Express } from "express";
import type { Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Socket.IO
  const io = new SocketIOServer(httpServer, {
    path: "/socket.io",
    cors: {
      origin: "*",
    },
  });

  const activeUsers = new Map<string, string>(); // socketId -> username

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join", async (username: string) => {
      activeUsers.set(socket.id, username);
      
      // Notify everyone
      io.emit("activeUsers", Array.from(new Set(activeUsers.values())));
      io.emit("systemMessage", `${username} joined the chat`);
      
      // Find or create user in DB
      try {
        await storage.createUser({ username });
      } catch (e) {
        console.error("Error creating user", e);
      }
    });

    socket.on("groupMessage", async (content: string) => {
      const sender = activeUsers.get(socket.id);
      if (!sender) return;

      try {
        const message = await storage.createMessage({
          sender,
          content,
          isPrivate: false,
        });
        
        io.emit("groupMessage", {
          sender: message.sender,
          message: message.content,
          id: message.id,
          timestamp: message.createdAt
        });
      } catch (e) {
        console.error("Error sending group message", e);
      }
    });

    socket.on("privateMessage", async ({ to, message: content }: { to: string; message: string }) => {
      const sender = activeUsers.get(socket.id);
      if (!sender) return;

      try {
        const msg = await storage.createMessage({
          sender,
          content,
          recipient: to,
          isPrivate: true,
        });

        const msgData = {
          sender,
          message: content,
          isPrivate: true,
          to,
          timestamp: msg.createdAt
        };

        // Emit to all sockets matching the username (distributed-like)
        Array.from(activeUsers.entries()).forEach(([id, username]) => {
          if (username === to) {
            io.to(id).emit("privateMessage", msgData);
          }
        });
        // Also send back to sender for their UI
        socket.emit("privateMessage", msgData);

      } catch (e) {
        console.error("Error sending private message", e);
      }
    });

    socket.on("disconnect", () => {
      const username = activeUsers.get(socket.id);
      if (username) {
        activeUsers.delete(socket.id);
        io.emit("activeUsers", Array.from(new Set(activeUsers.values())));
        io.emit("systemMessage", `${username} left the chat`);
      }
    });
  });

  // REST API Routes
  app.get(api.users.list.path, async (_req, res) => {
    const users = await storage.getUsers();
    res.json(users);
  });

  app.post(api.users.join.path, async (req, res) => {
    try {
      const input = api.users.join.input.parse(req.body);
      const user = await storage.createUser(input);
      res.status(200).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.messages.list.path, async (_req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  return httpServer;
}
