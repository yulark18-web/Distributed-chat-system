# Replit.md

## Overview

A real-time chat application with group messaging and private messaging capabilities. Users can join with a username, see active online users, and send messages in a shared chat room or privately to specific users. The app features a modern UI with smooth animations and real-time WebSocket communication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing (Login → Chat pages)
- **State Management**: TanStack React Query for server state, React hooks for local state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theme configuration (CSS variables for theming)
- **Animations**: Framer Motion for message animations and transitions
- **Real-time**: Socket.IO client for WebSocket communication

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Real-time**: Socket.IO server for bidirectional WebSocket communication
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod schemas with drizzle-zod for type-safe database schemas
- **Build**: esbuild for server bundling, Vite for client bundling

### Data Storage
- **Database**: PostgreSQL (configured via DATABASE_URL environment variable)
- **Schema**: Two main tables:
  - `users`: id, username (unique), isOnline status
  - `messages`: id, sender, content, recipient (nullable for group messages), isPrivate flag, createdAt timestamp
- **Session**: Username stored in browser sessionStorage for persistence across page reloads

### API Structure
- **REST Endpoints**:
  - `GET /api/users` - List all users
  - `POST /api/users/join` - Join chat with username
  - `GET /api/messages` - List all messages
- **WebSocket Events**:
  - `join` - User joins with username
  - `groupMessage` - Send message to everyone
  - `privateMessage` - Send direct message to specific user
  - `activeUsers` - Broadcast list of online users
  - `systemMessage` - System notifications (user joined/left)

### Key Design Patterns
- **Shared Types**: Schema definitions in `shared/` folder are used by both client and server
- **Storage Interface**: `IStorage` interface abstracts database operations for potential swapping
- **API Route Definitions**: Centralized in `shared/routes.ts` with Zod schemas for type safety
- **Path Aliases**: `@/` for client source, `@shared/` for shared code

## External Dependencies

### Database
- PostgreSQL database (required, connection via DATABASE_URL environment variable)
- Drizzle Kit for migrations (`npm run db:push`)

### Third-Party Libraries
- **Socket.IO**: Real-time bidirectional communication
- **Radix UI**: Accessible component primitives
- **Framer Motion**: Animation library
- **date-fns**: Date/time formatting
- **Zod**: Runtime type validation

### Development Tools
- **Vite**: Development server with HMR
- **esbuild**: Production server bundling
- **TypeScript**: Type checking across the stack