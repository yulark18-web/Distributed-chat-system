import { useState } from "react";
import { useLocation } from "wouter";
import { useJoinUser } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { MessageSquare, ArrowRight, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [username, setUsername] = useState("");
  const [, setLocation] = useLocation();
  const joinMutation = useJoinUser();
  const { toast } = useToast();

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;

    try {
      // First try to register/verify API side
      await joinMutation.mutateAsync({ username });
      
      // Save to session storage for persistence across reloads
      sessionStorage.setItem("chat_username", username);
      
      // Navigate to chat
      setLocation("/chat");
    } catch (error: any) {
      toast({
        title: "Error joining chat",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#F8F9FC] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] rounded-full bg-blue-500/5 blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md px-4 relative z-10"
      >
        <Card className="p-8 shadow-2xl border-white/50 bg-white/80 backdrop-blur-xl rounded-3xl">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 text-primary shadow-lg shadow-primary/10">
              <MessageSquare className="w-8 h-8" />
            </div>
            
            <h1 className="text-3xl font-display font-bold text-foreground mb-2">
              Welcome back
            </h1>
            <p className="text-muted-foreground">
              Enter a username to join the conversation
            </p>
          </div>

          <form onSubmit={handleJoin} className="space-y-4">
            <div className="space-y-2">
              <Input
                placeholder="Choose a username..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="h-12 rounded-xl border-border/60 bg-white/50 focus:bg-white transition-all text-lg px-4"
                disabled={joinMutation.isPending}
                autoFocus
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 rounded-xl text-lg font-medium shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
              disabled={joinMutation.isPending || !username.trim()}
            >
              {joinMutation.isPending ? (
                "Joining..."
              ) : (
                <span className="flex items-center gap-2">
                  Start Chatting <ArrowRight className="w-4 h-4" />
                </span>
              )}
            </Button>
            
            <div className="pt-4 text-center">
              <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                Secure, fast, and real-time messaging
              </p>
            </div>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}
