import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { useSocket, useMessages } from "@/hooks/use-chat";
import { UserList } from "@/components/UserList";
import { MessageBubble } from "@/components/MessageBubble";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Menu, X, Hash, Lock, Smile } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export default function Chat() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [selectedPrivateUser, setSelectedPrivateUser] = useState<string | null>(null);
  
  // Ref for auto-scrolling
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize username from session
  useEffect(() => {
    const stored = sessionStorage.getItem("chat_username");
    if (!stored) {
      setLocation("/");
      return;
    }
    setUsername(stored);
  }, [setLocation]);

  // Data & Socket hooks
  const { data: messages = [] } = useMessages();
  const { activeUsers, sendMessage, sendPrivateMessage } = useSocket(username);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    if (selectedPrivateUser) {
      sendPrivateMessage(selectedPrivateUser, messageInput);
    } else {
      sendMessage(messageInput);
    }
    setMessageInput("");
  };

  if (!username) return null;

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block h-full">
        <UserList 
          users={activeUsers} 
          currentUser={username} 
          onSelectUser={(u) => setSelectedPrivateUser(u === selectedPrivateUser ? null : u)}
          selectedUser={selectedPrivateUser}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Header */}
        <header className="h-16 px-6 border-b border-border/50 flex items-center justify-between bg-white/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            {/* Mobile Sidebar Trigger */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-80">
                <UserList 
                  users={activeUsers} 
                  currentUser={username} 
                  onSelectUser={(u) => setSelectedPrivateUser(u === selectedPrivateUser ? null : u)}
                  selectedUser={selectedPrivateUser}
                />
              </SheetContent>
            </Sheet>

            <div className="flex flex-col">
              <h1 className="text-lg font-display font-bold flex items-center gap-2">
                {selectedPrivateUser ? (
                  <>
                    <Lock className="w-4 h-4 text-amber-500" /> 
                    <span>Private with {selectedPrivateUser}</span>
                  </>
                ) : (
                  <>
                    <Hash className="w-4 h-4 text-primary" /> 
                    <span>General Chat</span>
                  </>
                )}
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                {selectedPrivateUser 
                  ? "Messages are only visible to both of you" 
                  : `Chatting with everyone • ${activeUsers.length} online`
                }
              </p>
            </div>
          </div>
          
          {selectedPrivateUser && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setSelectedPrivateUser(null)}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              <X className="w-3 h-3 mr-1" /> Close Private
            </Button>
          )}
        </header>

        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50/50">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
              <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center mb-4">
                <Smile className="w-10 h-10" />
              </div>
              <p>No messages yet. Say hello!</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <MessageBubble 
                key={idx} 
                message={msg} 
                isMe={msg.sender === username} 
              />
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="p-4 bg-white border-t border-border/50">
          <form onSubmit={handleSend} className="max-w-4xl mx-auto flex gap-2 relative">
            <div className="relative flex-1">
              <Input
                placeholder={selectedPrivateUser ? `Message ${selectedPrivateUser}...` : "Type a message..."}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                className="h-12 rounded-full pl-6 pr-12 border-border bg-slate-50 focus:bg-white transition-all shadow-sm focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer p-2">
                 <Smile className="w-5 h-5" />
              </div>
            </div>
            
            <Button 
              type="submit" 
              size="icon" 
              className={cn(
                "h-12 w-12 rounded-full shadow-md transition-all duration-200",
                messageInput.trim() ? "scale-100 opacity-100" : "scale-90 opacity-70"
              )}
              disabled={!messageInput.trim()}
            >
              <Send className="w-5 h-5 ml-0.5" />
            </Button>
          </form>
          <div className="text-center mt-2">
            <p className="text-[10px] text-muted-foreground">
              Enter sends message • Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
