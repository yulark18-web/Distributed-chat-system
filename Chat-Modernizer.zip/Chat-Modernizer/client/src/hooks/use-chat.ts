import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type InsertUser, type User, type Message } from "@shared/schema";
import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { useToast } from "@/hooks/use-toast";

// ============================================
// API HOOKS
// ============================================

export function useUsers() {
  return useQuery({
    queryKey: [api.users.list.path],
    queryFn: async () => {
      const res = await fetch(api.users.list.path);
      if (!res.ok) throw new Error("Failed to fetch users");
      return api.users.list.responses[200].parse(await res.json());
    },
  });
}

export function useMessages() {
  return useQuery({
    queryKey: [api.messages.list.path],
    queryFn: async () => {
      const res = await fetch(api.messages.list.path);
      if (!res.ok) throw new Error("Failed to fetch messages");
      return api.messages.list.responses[200].parse(await res.json());
    },
  });
}

export function useJoinUser() {
  return useMutation({
    mutationFn: async (userData: InsertUser) => {
      const res = await fetch(api.users.join.path, {
        method: api.users.join.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.users.join.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to join chat");
      }
      return api.users.join.responses[201].parse(await res.json());
    },
  });
}

// ============================================
// SOCKET HOOK
// ============================================

type ChatEvent = 
  | { type: 'message'; data: Message }
  | { type: 'system'; message: string }
  | { type: 'activeUsers'; users: string[] };

export function useSocket(username: string | null) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [activeUsers, setActiveUsers] = useState<string[]>([]);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    if (!username) return;

    const newSocket = io(window.location.host);

    newSocket.on("connect", () => {
      console.log("Connected to socket server");
      newSocket.emit("join", username);
    });

    newSocket.on("activeUsers", (users: string[]) => {
      setActiveUsers(users);
      // Also invalidate the users list query to sync full user objects if needed
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
    });

    newSocket.on("groupMessage", (data: Message) => {
      queryClient.setQueryData([api.messages.list.path], (old: Message[] = []) => {
        return [...old, data];
      });
    });

    newSocket.on("privateMessage", (data: Message) => {
      queryClient.setQueryData([api.messages.list.path], (old: Message[] = []) => {
        return [...old, data];
      });
      toast({
        title: `Private message from ${data.sender}`,
        description: data.content,
      });
    });

    newSocket.on("systemMessage", (msg: string) => {
      toast({
        title: "System",
        description: msg,
        duration: 3000,
      });
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [username, queryClient, toast]);

  const sendMessage = (content: string) => {
    if (socket) socket.emit("groupMessage", content);
  };

  const sendPrivateMessage = (to: string, message: string) => {
    if (socket) socket.emit("privateMessage", { to, message });
  };

  return { socket, activeUsers, sendMessage, sendPrivateMessage };
}
