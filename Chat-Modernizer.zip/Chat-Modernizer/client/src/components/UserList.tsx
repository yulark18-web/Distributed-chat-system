import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface UserListProps {
  users: string[]; // List of usernames
  currentUser: string;
  onSelectUser: (username: string) => void;
  selectedUser: string | null;
}

export function UserList({ users, currentUser, onSelectUser, selectedUser }: UserListProps) {
  // Filter out current user from the list to show "Others"
  const otherUsers = users.filter(u => u !== currentUser);

  return (
    <div className="flex flex-col h-full bg-secondary/30 border-r border-border/50 w-80 backdrop-blur-xl">
      <div className="p-4 border-b border-border/50">
        <h2 className="text-lg font-display font-bold text-foreground">Active Users</h2>
        <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
          </span>
          {users.length} online now
        </p>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-2">
          {otherUsers.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground text-sm border-2 border-dashed border-border rounded-xl">
              No one else is online right now. 
              <br />
              Invite a friend!
            </div>
          ) : (
            otherUsers.map((username) => (
              <button
                key={username}
                onClick={() => onSelectUser(username)}
                className={cn(
                  "w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200",
                  "hover:bg-background/80 hover:shadow-sm",
                  selectedUser === username 
                    ? "bg-background shadow-md border border-border/50 ring-1 ring-primary/20" 
                    : "transparent"
                )}
              >
                <div className="relative">
                  <Avatar className="h-10 w-10 border-2 border-background shadow-sm">
                    <AvatarFallback className="bg-primary/10 text-primary font-bold">
                      {username.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-white"></span>
                </div>
                
                <div className="flex-1 text-left">
                  <p className="font-semibold text-sm text-foreground">{username}</p>
                  <p className="text-xs text-muted-foreground truncate">Click to message privately</p>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
      
      <div className="p-4 border-t border-border/50 bg-background/50">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9">
            <AvatarFallback className="bg-foreground text-background">
              {currentUser.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">You ({currentUser})</p>
            <p className="text-xs text-muted-foreground">Online</p>
          </div>
        </div>
      </div>
    </div>
  );
}
