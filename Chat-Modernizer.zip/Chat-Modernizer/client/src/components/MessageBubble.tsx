import { Message } from "@shared/schema";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Lock, User } from "lucide-react";

interface MessageBubbleProps {
  message: Message;
  isMe: boolean;
}

export function MessageBubble({ message, isMe }: MessageBubbleProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={cn(
        "flex w-full mb-4",
        isMe ? "justify-end" : "justify-start"
      )}
    >
      <div className={cn("max-w-[80%] md:max-w-[60%] flex flex-col", isMe ? "items-end" : "items-start")}>
        {!isMe && (
          <span className="text-xs font-medium text-muted-foreground mb-1 ml-1 flex items-center gap-1">
            {message.sender}
          </span>
        )}
        
        <div
          className={cn(
            "px-4 py-3 rounded-2xl text-sm shadow-sm relative group transition-all duration-200",
            isMe 
              ? "bg-primary text-primary-foreground rounded-br-none hover:shadow-md" 
              : "bg-white text-foreground rounded-bl-none border border-border/50 hover:shadow-md",
            message.isPrivate && !isMe && "bg-amber-50 border-amber-200 text-amber-900"
          )}
        >
          {message.isPrivate && (
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider font-bold opacity-70 mb-1">
              <Lock className="w-3 h-3" /> Private Message
            </div>
          )}
          
          <p className="leading-relaxed whitespace-pre-wrap">{message.content}</p>
          
          <div className={cn(
            "text-[10px] mt-1 text-right opacity-70",
            isMe ? "text-primary-foreground/80" : "text-muted-foreground"
          )}>
            {message.createdAt ? format(new Date(message.createdAt), "h:mm a") : "Just now"}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
