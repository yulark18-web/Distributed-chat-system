## Packages
socket.io-client | Real-time WebSocket communication
framer-motion | Smooth animations for messages and transitions
date-fns | Message timestamp formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
Socket.IO connects to window.location.host
